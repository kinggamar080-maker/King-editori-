# KING EDITORI — Photography Website

## Quick editing
1. Open `index.html` to change the site name, text, email, and social links.
2. Put your photos inside the `images` folder.
3. Replace:
   - `hero.jpg`
   - `photo-1.jpg`
   - `photo-2.jpg`
   - `photo-3.jpg`
   - `photo-4.jpg`
   - `photo-5.jpg`
   - `photo-6.jpg`
4. Keep the filenames the same for the easiest setup.
5. Open `index.html` in a browser.

## Add more photos
Copy a `<figure class="photo"...>` block in `index.html`, change its image filename, category, number, and caption.

No server or database is required for this version.
