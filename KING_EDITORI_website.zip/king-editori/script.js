const filters = document.querySelectorAll(".filter");
const photos = document.querySelectorAll(".photo");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");
const lightboxCaption = document.getElementById("lightboxCaption");
const close = document.getElementById("closeLightbox");

filters.forEach(button => {
  button.addEventListener("click", () => {
    filters.forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    const selected = button.dataset.filter;
    photos.forEach(photo => {
      photo.style.display = selected === "all" || photo.dataset.category === selected ? "" : "none";
    });
  });
});

photos.forEach(photo => {
  photo.addEventListener("click", () => {
    const img = photo.querySelector("img");
    lightboxImg.src = img.src;
    lightboxImg.alt = img.alt;
    lightboxCaption.textContent = photo.querySelector("figcaption").textContent.trim();
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
  });
});

function closeBox() {
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
  lightboxImg.src = "";
}
close.addEventListener("click", closeBox);
lightbox.addEventListener("click", e => { if (e.target === lightbox) closeBox(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeBox(); });
